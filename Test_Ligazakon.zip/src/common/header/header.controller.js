(function() {
    'use strict';

    angular
        .module('ligazakontestapp')
        .controller('HeaderCtrl', HeaderCtrl);

    /* ngInject */
    function HeaderCtrl($rootScope, userService) {
        var vm = this;

    }
})();
