(function() {
    'use strict';

    angular
        .module('ligazakontestapp')
        .controller('FooterCtrl', FooterCtrl);

    /* ngInject */
    function FooterCtrl($rootScope) {
        var vm = this;

    }
})();
