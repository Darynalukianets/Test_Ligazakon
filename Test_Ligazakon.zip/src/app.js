(function() {
    'use strict';
    angular
        .module('ligazakontestapp', [
            'ui.bootstrap',
            'testligazakon.routing',
        ]);
})();


